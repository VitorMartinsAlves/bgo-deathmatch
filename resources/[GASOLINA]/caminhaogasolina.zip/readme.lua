--[[
	Resource generated with Vehicles Replacement Resource Generator.
	Visit:
	http://mta.dzek.eu/
		
	Created by
	Jacek Nowacki a.k.a. DZEK a.k.a. varez
]]--