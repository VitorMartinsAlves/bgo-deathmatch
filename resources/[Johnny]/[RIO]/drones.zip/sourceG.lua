drones = {
	[1] = 501, 
}

controls = {
	w = "accelerate",
	s = "brake_reverse",
	arrow_u = "steer_forward",
	arrow_d = "steer_back",
	a = "vehicle_look_left",
	d = "vehicle_look_right",
}

views = {
	{0, 2, -2},
	{0, 0, -5},
	{0, 2, 0}
}

modes = {
	"normal",
	"thermalvision",
	"nightvision"
}

lostSignalDistance = 150